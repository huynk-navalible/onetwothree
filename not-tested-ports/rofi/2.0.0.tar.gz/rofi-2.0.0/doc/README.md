Manpages are build using [pandoc](https://pandoc.org/)

Manpages can be updated using the following make command:

```
make generate-manpage
```
