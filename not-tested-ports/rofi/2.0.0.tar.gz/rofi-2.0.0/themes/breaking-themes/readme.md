Test themes that broke in the past.
